# -*- coding: utf-8 -*-

from Trading.Strategy.Strategy import *
from Trading.Strategy.Strategy_PCA import *
from Trading.Execution.Broker.Broker import *
from Trading.Strategy.Rules.Rule import *
from Trading.Execution.Broker.Order import *

from Trading.Strategy.Rules.Production.MTF_PCA.multiframe_pca import *

import time

class AlgoRunner ():
    def __init__ (self, strats = [], brokers = [], sleep_time=1800, bVerbose=False):
        self.strats = strats
        self.brokers = brokers
        self.sleep_time = sleep_time
        self.bVerbose = bVerbose
        
    def run (self):
        self.reconcileAllPositions ()
        self.orders = []
        for strat in self.strats:
            strat.open_positions = self.overall_pos
            for instrument in strat.instruments:
                
                strat.updateSignals (last_time_stamp=self.brokers[0].get_last_timestamp (), 
                                     instrument = instrument)
                if self.bVerbose:
                    print ('Updating signal instrument: ' + instrument)
                    print (strat.signals[instrument])
                orders, open_slots = strat.processSignals ()                
                
                if open_slots < len(orders):
                    orders = orders [0:open_slots]
    
                self.orders += orders
                print ('Processing order: ' + str(orders))
                self.processOrders ()
        
        time.sleep (self.sleep_time)
        
    def reconcileAllPositions (self):
        self.overall_pos = {}
        for broker in self.brokers:
            pos = broker.get_open_positions ()
            
            a = self.overall_pos
            b = pos
            
            r = dict(a.items() + b.items() +
                    [(k, a[k] + b[k]) for k in set(b) & set(a)])
            
            self.overall_pos = r
            
    def processOrders (self):
        print (self.orders)
        broker = self.brokers [0]
        for order in self.orders:
            px = broker.get_last_price (instrument=order.instrument)            
            
            if px['status'] == u'tradeable':
                bid_offer = float(px['asks'][0]['price']) / float(px['bids'][0]['price']) - 1.0
                mid_px = (float(px['asks'][0]['price']) + float(px['bids'][0]['price'])) / 2.0

                ask_px_str = px['asks'][0]['price']
                order.px_precision = np.maximum(len(ask_px_str[ask_px_str.find('.') + 1:]), 2)                

                if order.stop_loss_pct / bid_offer > 20.0:
                    if order.units > 0 and (float(px['asks'][0]['price']) / order.signal_price - 1.0) < order.stop_loss_pct / 20.0:
                        order.stop_loss_px = (1.0 - order.stop_loss_pct) * mid_px
                        order.target_px = (1.0 + order.target_pct) * mid_px
                        broker.send_order (order)
                    elif order.units < 0 and (float(px['bids'][0]['price']) / order.signal_price - 1.0) > - order.stop_loss_pct / 20.0:
                        order.stop_loss_px = (1.0 + order.stop_loss_pct) * mid_px
                        order.target_px = (1.0 - order.target_pct) * mid_px
                        broker.send_order (order)
        self.orders = []
        
if __name__ == "__main__":
    filename = os.path.join(CONFIG_PROD_RULE_PATH, 'MTF_PCA', 'default_loose.stp')
    f = open (filename, 'r')
    kwargs = eval(f.read ())
    
    from Trading.Strategy.Rules.Rule import *
    rule=Rule(name='prod_mtf_pca', func = mtf_pca,
              filter_instrument_func = mtf_pca_filter_slow_and_fast,
              bUseHighLowFeatures = True,
              args=kwargs, ruleType='MultiTimeframe', 
              target_multiple=1.5)
    
    st = Strategy_PCA(rule=rule, instruments = ['USD_ZAR'])
    broker = Oanda(my_config=V20_CONF)
    
    runner = AlgoRunner (strats=[st], 
                         brokers=[broker])
    
    broker.get_last_timestamp ()
    
    start = time.time ()
    
    if True:    
        st.updateSignals (last_timestamp = broker.last_timestamp,
                      instrument_list=full_instrument_list,
                      bComputePC=False)
    
    print ('Updated signals in ' + str (int(time.time () - start)) + ' seconds')

    for k in st.pred_dict.keys ():
        if st.pred_dict[k].dot(st.pred_dict[k]) != 0:
            if True:
                fig = plt.figure ()
                plt.title (k)
                axes = plt.gca()
                ax = axes.twinx ()
                axes.plot(st.pred_dict[k], color='red')
                st.ds.loadSeriesOnline (instrument=k)
                ax.plot(st.ds.df['Close'], color='black')
                plt.show ()

        